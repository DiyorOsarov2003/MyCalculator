# Welcome to My Reactjs Calculator
By Diyorbek Osarov

## Task
TODO - What is the problem? And where is the challenge?
Create a ReactJS Application.
It will be a single route application.
You will be able to perform all simple operation: +-/*

## Description
TODO - How have you solved the problem?
I used a hook that useState
methods: concat, slice, 
easy to understanding my function

## Installation
TODO - How to install your project? npm install? make? make re?
When you create react app, node modules automatically install


## Usage
TODO - How does it work?
Here you only run >>> 1- cd mycalculator 2- npm start
At the end you can see it on your window 
port is default at 3000(react)

### The Core Team
Diyorbek
<a href="https://github.com/DiyorOsarov2003">MyCalculator</a>


<span><i>Made at <a href='https://qwasar.io'>Qwasar Silicon Valley</a></i></span>
<span><img alt='Qwasar Silicon Valley Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
